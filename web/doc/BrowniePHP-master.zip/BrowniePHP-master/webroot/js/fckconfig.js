﻿FCKConfig.ToolbarSets["Brownie"] = [
	['Bold','Italic','Underline','TextColor','-','Link','Unlink','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyFull','OrderedList','UnorderedList','Table'],
	['Source','RemoveFormat']
] ;

FCKConfig.ProcessHTMLEntities = false; 
FCKConfig.IncludeLatinEntities = false; 
FCKConfig.IncludeGreekEntities = false;
