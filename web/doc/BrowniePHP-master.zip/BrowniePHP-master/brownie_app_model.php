<?php

class BrownieAppModel extends AppModel {

	var $actsAs = array('Containable');

}