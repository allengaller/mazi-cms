<?php
class Image extends BrownieAppModel{

	var $name = 'Image';
	var $useTable = false;

}
?>